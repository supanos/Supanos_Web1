# Supono's Sports Bar — Full-Stack (Next.js + Prisma + Postgres)

## Quick Start (Docker / DigitalOcean)
```bash
# 1) Copy env
cp .env.example .env

# (Optional) edit .env → set ADMIN_USERNAME / ADMIN_PASSWORD / DOMAIN / SMTP_*

# 2) Start
docker compose up -d --build

# 3) Run migrations + seed (open a shell inside container or run locally)
docker compose exec web npx prisma migrate deploy
docker compose exec web node -e "require('child_process').execSync('npm run seed',{stdio:'inherit'})"
```

Open: http://your-droplet-ip:3000

Admin: `/${ADMIN_PATH}` → default `/_suponos-admin_4k7g`

## Features
- Menu (categories, items, tags, flags, allergens)
- Games (NFL & MLB) — manual seed + `/api/games/sync` endpoint (wire to DO Cron later)
- Promotions (Happy Hour seeded Mon–Fri 16:00–19:00)
- Reservations (max online party 9; **10+ prompts to call**; one-per-day per phone/email)
- Site Settings (logo text, contact, hours as JSON)
- Email notifications (admin on new reservation; customer on approve) via SMTP

## Dev
```bash
npm i
npx prisma migrate dev --name init
npm run dev
```

## Deploy Notes
- Use DigitalOcean **Docker 1-Click** droplet (2 vCPU / 2GB RAM).
- Point domain → droplet. For SSL, add a reverse proxy (Caddy or Nginx) or use DO App Platform.
- Cron for games: call `POST https://yourdomain.com/api/games/sync` hourly using DO Cron or UptimeRobot.
```

