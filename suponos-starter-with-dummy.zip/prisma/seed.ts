import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  const adminUser = process.env.ADMIN_USERNAME || 'admin'
  const adminPass = process.env.ADMIN_PASSWORD || 'change-me'
  const hash = await bcrypt.hash(adminPass, 10)

  await prisma.adminUser.upsert({
    where: { username: adminUser },
    create: { username: adminUser, passwordHash: hash },
    update: { passwordHash: hash },
  })

  // default categories
  const cats = ['Starters','Mains','Sides','Desserts','Drinks']
  for (let i=0;i<cats.length;i++) {
    await prisma.category.upsert({
      where: { slug: cats[i].toLowerCase() },
      create: { name: cats[i], slug: cats[i].toLowerCase(), order: i },
      update: {}
    })
  }

  // default happy hour Mon-Fri 16:00-19:00
  await prisma.promotion.upsert({
    where: { id: 1 },
    create: {
      type: 'HAPPY_HOUR',
      title: 'Happy Hour Specials',
      description: '50% off drafts, $2 off cocktails, 25% off appetizers',
      days: ['Mon','Tue','Wed','Thu','Fri'],
      startTime: '16:00',
      endTime: '19:00',
      active: true
    },
    update: {}
  })

  
  // dummy menu items with images
  const starters = await prisma.category.findFirst({ where: { slug: 'starters' } })
  const mains = await prisma.category.findFirst({ where: { slug: 'mains' } })
  const sides = await prisma.category.findFirst({ where: { slug: 'sides' } })
  const desserts = await prisma.category.findFirst({ where: { slug: 'desserts' } })
  const drinks = await prisma.category.findFirst({ where: { slug: 'drinks' } })

  if (starters && mains && sides && desserts && drinks) {
    await prisma.menuItem.createMany({
      data: [
        { title: 'Chopped Cheese Egg Rolls', description: 'Fried flounder, shrimp, American cheese & hot sauce.', price: 14.00, categoryId: starters.id, imageUrl: '/images/starters-eggrolls.png', flags: ['spicy'], contains: ['gluten','dairy','shellfish'] },
        { title: 'Coconut Shrimp', description: 'Jumbo shrimp with sweet Thai chili.', price: 17.00, categoryId: starters.id, imageUrl: '/images/starters-shrimp.png', contains: ['gluten','shellfish'] },
        { title: 'House Pub Burger', description: 'Lettuce, cheese, house sauce. +Fries (+$3).', price: 15.00, categoryId: mains.id, imageUrl: '/images/mains-burger.png', contains: ['gluten','dairy'] },
        { title: 'Buffalo Wings', description: 'Choice of sauces: Sweet Heat, Honey Hickory, FOE, Plain.', price: 19.00, categoryId: mains.id, imageUrl: '/images/mains-wings.png' },
        { title: 'Loaded Fries', description: 'Lamb glaze & pub sauce.', price: 12.00, categoryId: sides.id, imageUrl: '/images/sides-fries.png' },
        { title: 'NY Cheesecake', description: 'Classic slice.', price: 9.00, categoryId: desserts.id, imageUrl: '/images/desserts-cheesecake.png', contains: ['dairy','gluten'] },
        { title: 'Draft Beer (pint)', description: 'Ask for rotating taps.', price: 7.00, categoryId: drinks.id, imageUrl: '/images/drinks-draft.png' },
        { title: 'Signature Cocktail', description: 'Bartender special.', price: 12.00, categoryId: drinks.id, imageUrl: '/images/drinks-cocktail.png' },
      ]
    })
  }

  console.log('Seed complete.')
}

main().finally(()=>prisma.$disconnect())
