'use client'
import { useEffect, useState } from 'react'

export default function Settings(){
  const [s,setS] = useState<any>({})
  useEffect(()=>{ fetch('/api/settings').then(r=>r.json()).then(setS) },[])
  function ch(k:string,v:any){ setS((p:any)=>({...p,[k]:v})) }
  async function save(){ await fetch('/api/settings',{ method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(s) }) }
  return (
    <div className="grid md:grid-cols-2 gap-4">
      <div className="card space-y-2">
        <div className="font-bold mb-2">Site Settings</div>
        <input value={s.siteName||''} onChange={e=>ch('siteName',e.target.value)} placeholder="Site Name"/>
        <input value={s.logoText||''} onChange={e=>ch('logoText',e.target.value)} placeholder="Logo Text"/>
        <input value={s.address||''} onChange={e=>ch('address',e.target.value)} placeholder="Address"/>
        <input value={s.phone||''} onChange={e=>ch('phone',e.target.value)} placeholder="Phone"/>
        <input value={s.email||''} onChange={e=>ch('email',e.target.value)} placeholder="Email"/>
        <textarea value={JSON.stringify(s.hoursJson||{},null,2)} onChange={e=>ch('hoursJson',JSON.parse(e.target.value||'{}'))} placeholder='{"Mon-Thu":"11:00-23:00"}'/>
        <button className="btn" onClick={save}>Save</button>
      </div>
      <div className="card">
        <div className="font-bold mb-2">Promotions</div>
        <p className="text-sm opacity-75">Default Happy Hour: Mon–Fri 16:00–19:00 (from seed)</p>
      </div>
    </div>
  )
}
