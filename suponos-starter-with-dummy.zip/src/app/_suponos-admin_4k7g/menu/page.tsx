'use client'
import { useEffect, useState } from 'react'

export default function AdminMenu(){
  const [cats, setCats] = useState<any[]>([])
  const [name, setName] = useState('')
  async function load(){
    const r = await fetch('/api/menu/categories'); setCats(await r.json())
  }
  useEffect(()=>{ load() },[])
  async function addCat(e:any){
    e.preventDefault()
    await fetch('/api/menu/categories', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ name }) })
    setName(''); load()
  }
  return (
    <div className="grid md:grid-cols-2 gap-4">
      <div className="card">
        <div className="font-bold mb-2">Categories</div>
        <form onSubmit={addCat} className="flex gap-2">
          <input value={name} onChange={e=>setName(e.target.value)} placeholder="Category name" required/>
          <button className="btn">Add</button>
        </form>
        <ul className="mt-4 space-y-2">
          {cats.map(c=>(<li key={c.id} className="flex items-center justify-between"><span>{c.name}</span></li>))}
        </ul>
      </div>
      <div className="card">
        <div className="font-bold mb-2">Add Menu Item</div>
        <ItemForm cats={cats} onSaved={load}/>
      </div>
    </div>
  )
}

function ItemForm({cats,onSaved}:{cats:any[],onSaved:()=>void}){
  async function submit(e:any){
    e.preventDefault()
    const r = await fetch('/api/menu/items', { method:'POST', body: new FormData(e.currentTarget) })
    if (r.ok) { e.currentTarget.reset(); onSaved() }
  }
  return (
    <form onSubmit={submit} className="grid gap-2">
      <input name="title" placeholder="Title" required/>
      <textarea name="description" placeholder="Description"/>
      <input name="price" type="number" step="0.01" placeholder="Price" required/>
      <select name="categoryId" required>
        <option value="">Select category</option>
        {cats.map(c=>(<option key={c.id} value={c.id}>{c.name}</option>))}
      </select>
      <input name="tags" placeholder="Tags (comma separated)"/>
      <input name="flags" placeholder="Flags (spicy, vegan, gluten-free)"/>
      <input name="contains" placeholder="Contains (allergens)"/>
      <button className="btn">Save</button>
    </form>
  )
}
