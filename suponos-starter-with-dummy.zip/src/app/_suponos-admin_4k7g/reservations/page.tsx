'use client'
import { useEffect, useState } from 'react'

export default function AdminRes(){
  const [rows, setRows] = useState<any[]>([])
  async function load(){ const r = await fetch('/api/reservations'); setRows(await r.json()) }
  useEffect(()=>{ load() },[])
  async function approve(id:number){ await fetch('/api/reservations/'+id+'/approve',{method:'POST'}); load() }
  async function decline(id:number){ await fetch('/api/reservations/'+id+'/decline',{method:'POST'}); load() }
  return (
    <div className="card">
      <div className="font-bold mb-3">Reservations</div>
      <table>
        <thead><tr><th>When</th><th>Name</th><th>Party</th><th>Contact</th><th>Status</th><th/></tr></thead>
        <tbody>
          {rows.map(r=>(
            <tr key={r.id}>
              <td>{new Date(r.startsAt).toLocaleString()}</td>
              <td>{r.name}</td>
              <td>{r.partySize}</td>
              <td>{r.phone} / {r.email}</td>
              <td>{r.status}</td>
              <td className="flex gap-2">
                {r.status==='PENDING' && <button className="btn" onClick={()=>approve(r.id)}>Approve</button>}
                {r.status!=='DECLINED' && <button className="btn-outline" onClick={()=>decline(r.id)}>Decline</button>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
