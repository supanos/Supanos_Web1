'use client'
import { useState } from 'react'

export default function AdminLogin(){
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  async function login(e:any){
    e.preventDefault(); setLoading(true); setErr(null)
    const form = new FormData(e.currentTarget)
    const res = await fetch('/api/auth/login', { method:'POST', body: form })
    if (res.ok) window.location.href = `/${encodeURIComponent('_suponos-admin_4k7g')}/dashboard`
    else { const j=await res.json(); setErr(j.error||'Login failed') }
    setLoading(false)
  }
  return (
    <div className="max-w-sm mx-auto card">
      <h1 className="text-2xl font-bold mb-4">Admin Login</h1>
      <form onSubmit={login} className="space-y-3">
        <div><label>Username</label><input name="username" required/></div>
        <div><label>Password</label><input name="password" type="password" required/></div>
        <button className="btn w-full" disabled={loading}>{loading?'...':'Login'}</button>
        {err && <div className="text-red-400 text-sm">{err}</div>}
      </form>
    </div>
  )
}
