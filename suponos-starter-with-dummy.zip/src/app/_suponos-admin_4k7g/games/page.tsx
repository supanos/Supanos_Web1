'use client'
import { useEffect, useState } from 'react'

export default function AdminGames(){
  const [rows,setRows] = useState<any[]>([])
  async function load(){ const r=await fetch('/api/games'); setRows(await r.json()) }
  useEffect(()=>{ load() },[])
  async function sync(){ await fetch('/api/games/sync',{ method:'POST' }); load() }
  return (
    <div className="card">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-bold">Games</div>
          <div className="text-sm opacity-75">NFL & MLB schedule (manual seed & API-ready)</div>
        </div>
        <button className="btn" onClick={sync}>Sync Now</button>
      </div>
      <table className="mt-3">
        <thead><tr><th>Date</th><th>League</th><th>Away</th><th>Home</th><th>Status</th></tr></thead>
        <tbody>
          {rows.map(g=>(<tr key={g.id}><td>{new Date(g.startsAt).toLocaleString()}</td><td>{g.league}</td><td>{g.awayTeam}</td><td>{g.homeTeam}</td><td>{g.status}</td></tr>))}
        </tbody>
      </table>
    </div>
  )
}
