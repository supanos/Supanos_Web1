import '../../styles/globals.css'
export const metadata = { title: "Admin | Supono's" }
export default function AdminLayout({children}:{children:React.ReactNode}){
  return <div className="container py-10">{children}</div>
}
