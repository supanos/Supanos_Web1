import Link from 'next/link'

export default function Dashboard(){
  return (
    <div className="grid md:grid-cols-2 gap-4">
      <div className="card">
        <div className="font-bold">Menu</div>
        <p className="opacity-75 text-sm">Manage categories & items</p>
        <Link className="btn mt-3" href="./menu">Open</Link>
      </div>
      <div className="card">
        <div className="font-bold">Reservations</div>
        <p className="opacity-75 text-sm">Approve or decline</p>
        <Link className="btn mt-3" href="./reservations">Open</Link>
      </div>
      <div className="card">
        <div className="font-bold">Games</div>
        <p className="opacity-75 text-sm">NFL & MLB schedule</p>
        <Link className="btn mt-3" href="./games">Open</Link>
      </div>
      <div className="card">
        <div className="font-bold">Settings</div>
        <p className="opacity-75 text-sm">Site settings & promotions</p>
        <Link className="btn mt-3" href="./settings">Open</Link>
      </div>
    </div>
  )
}
