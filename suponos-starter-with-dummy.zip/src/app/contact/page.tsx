import { prisma } from '@/lib/prisma'

export default async function Contact(){
  const s = await prisma.setting.findFirst()
  const hours = (s?.hoursJson as any) || {}
  return (
    <div className="container my-10">
      <h1 className="text-4xl font-bold mb-6">Find Us</h1>
      <div className="grid md:grid-cols-2 gap-6">
        <div className="card space-y-2">
          <div><b>Address:</b> {s?.address}</div>
          <div><b>Phone:</b> {s?.phone}</div>
          <div><b>Email:</b> {s?.email}</div>
          <a className="btn mt-3" href="tel:+1">{'Call Now'}</a>
        </div>
        <div className="card">
          <div className="font-semibold">Hours</div>
          <pre className="text-sm opacity-80 whitespace-pre-wrap">{JSON.stringify(hours, null, 2)}</pre>
        </div>
      </div>
    </div>
  )
}
