'use client'
import { useState } from 'react'

export default function Reserve(){
  const [loading, setLoading] = useState(false)
  const [ok, setOk] = useState<string | null>(null)
  async function submit(e: any){
    e.preventDefault(); setLoading(true); setOk(null)
    const form = new FormData(e.currentTarget)
    const res = await fetch('/api/reservations', { method:'POST', body: form })
    const j = await res.json()
    setLoading(false)
    setOk(res.ok ? 'Request received! We will confirm by email.' : j.error || 'Error')
  }
  return (
    <div className="container my-10">
      <h1 className="text-4xl font-bold mb-6">Reserve a Table</h1>
      <form onSubmit={submit} className="card grid md:grid-cols-2 gap-4">
        <div><label>Name</label><input name="name" required/></div>
        <div><label>Email</label><input name="email" type="email" required/></div>
        <div><label>Phone</label><input name="phone" required/></div>
        <div><label>Party Size</label><input name="partySize" type="number" min={1} max={20} required/></div>
        <div><label>Date</label><input name="date" type="date" required/></div>
        <div><label>Time</label><input name="time" type="time" required/></div>
        <div className="md:col-span-2"><label>Notes</label><textarea name="note"/></div>
        <div className="md:col-span-2"><button className="btn" disabled={loading}>{loading?'Submitting...':'Submit Reservation'}</button></div>
        {ok && <div className="md:col-span-2">{ok}</div>}
      </form>
    </div>
  )
}
