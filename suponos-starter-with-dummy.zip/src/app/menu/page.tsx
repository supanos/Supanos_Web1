import { prisma } from '@/lib/prisma'

export default async function MenuPage(){
  const cats = await prisma.category.findMany({ include: { items: { where: { isActive: true }, orderBy: { order: 'asc' } } }, orderBy: { order: 'asc' } })
  return (
    <div className="container my-10">
      <h1 className="text-4xl font-bold mb-6">Our Menu</h1>
      <div className="grid gap-8">
        {cats.map(cat => (
          <div key={cat.id}>
            <h2 className="text-2xl font-bold mb-3">{cat.name}</h2>
            <div className="grid md:grid-cols-3 gap-4">
              {cat.items.map(item => (
                <div className="card" key={item.id}>
                  <div className="flex items-center justify-between">
                    <div className="font-semibold">{item.title}</div>
                    <div className="text-[var(--accent)] font-bold">${item.price.toString()}</div>
                  </div>
                  {item.description && <p className="text-sm opacity-80 mt-2">{item.description}</p>}
                </div>
              ))}
              {cat.items.length===0 && <div className="opacity-70">No items yet.</div>}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
