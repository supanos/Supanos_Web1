import { prisma } from '@/lib/prisma'

export default async function EventsPage(){
  const events = await prisma.event.findMany({ where: { active: true }, orderBy: { startsAt: 'asc' } })
  return (
    <div className="container my-10">
      <h1 className="text-4xl font-bold mb-6">Upcoming Events</h1>
      <div className="grid md:grid-cols-3 gap-4">
        {events.map(ev => (
          <div key={ev.id} className="card">
            <div className="text-xs opacity-70">{new Date(ev.startsAt).toLocaleDateString()}</div>
            <div className="text-lg font-bold">{ev.title}</div>
            {ev.description && <p className="opacity-80 text-sm mt-1">{ev.description}</p>}
          </div>
        ))}
        {events.length===0 && <div className="opacity-70">No events scheduled.</div>}
      </div>
    </div>
  )
}
