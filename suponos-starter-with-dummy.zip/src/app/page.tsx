import Hero from '@/components/Hero'
import Link from 'next/link'

async function getTodayGames() {
  const res = await fetch(`${process.env.DOMAIN || ''}/api/games/today`, { cache: 'no-store' }).catch(()=>null as any)
  if (!res?.ok) return []
  return res.json()
}

export default async function Home(){
  const games = await getTodayGames()
  return (
    <>
      <Hero/>
      <section id="today-matches" className="container my-10">
        <h2 className="text-3xl font-bold mb-4">Today&apos;s Matches</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {games.map((g:any)=>(
            <div key={g.id} className="card">
              <div className="text-xs opacity-70">{g.league}</div>
              <div className="text-lg font-bold mt-1">{g.awayTeam} @ {g.homeTeam}</div>
              <div className="opacity-80">{new Date(g.startsAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</div>
              <div className="mt-2"><span className="text-xs px-2 py-1 rounded bg-slate-800">{g.status}</span></div>
            </div>
          ))}
          {games.length===0 && <div className="opacity-70">No games today. Check back later.</div>}
        </div>
      </section>

      <section className="container my-10">
        <div className="card flex items-center justify-between">
          <div>
            <div className="text-sm">Mon–Fri</div>
            <h3 className="text-2xl font-bold">Happy Hour Specials</h3>
            <p className="opacity-75">50% off drafts • $2 off cocktails • 25% off appetizers</p>
          </div>
          <Link href="/menu" className="btn">View Full Menu</Link>
        </div>
      </section>

    </>
  )
}
