import { NextRequest, NextResponse } from 'next/server'
import { authenticate } from '@/lib/auth'

export async function POST(req: NextRequest){
  const form = await req.formData()
  const username = String(form.get('username')||'')
  const password = String(form.get('password')||'')
  const token = await authenticate(username, password)
  if (!token) return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })
  const res = NextResponse.json({ ok: true })
  res.cookies.set('admintoken', token, { httpOnly: true, secure: true, sameSite: 'lax', maxAge: 60*60*24*7, path:'/' })
  return res
}
