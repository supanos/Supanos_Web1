import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getTransport } from '@/lib/email'

export async function GET(){
  const rows = await prisma.reservation.findMany({ orderBy: { startsAt: 'desc' }, take: 200 })
  return NextResponse.json(rows)
}

export async function POST(req: NextRequest){
  const form = await req.formData()
  const name = String(form.get('name')||'')
  const email = String(form.get('email')||'')
  const phone = String(form.get('phone')||'')
  const partySize = parseInt(String(form.get('partySize')||'0'),10)
  const date = String(form.get('date')||'')
  const time = String(form.get('time')||'')
  const note = String(form.get('note')||'')

  if (!name || !email || !phone || !partySize || !date || !time) return NextResponse.json({error:'missing fields'},{status:400})

  if (partySize >= 10) {
    return NextResponse.json({ error: 'For groups of 10+, please call the bar to arrange a group reservation.' }, { status: 400 })
  }

  const startsAt = new Date(`${date}T${time}:00`)

  // one per day per contact
  const dayStart = new Date(startsAt); dayStart.setHours(0,0,0,0)
  const dayEnd = new Date(startsAt); dayEnd.setHours(23,59,59,999)
  const dup = await prisma.reservation.findFirst({ where: {
    startsAt: { gte: dayStart, lte: dayEnd },
    OR: [{ email }, { phone }]
  } })
  if (dup) return NextResponse.json({ error: 'You already have a reservation for this day.' }, { status: 400 })

  const row = await prisma.reservation.create({ data: { name, email, phone, partySize, startsAt, note } })

  // notify admin
  const transport = getTransport()
  const adminEmail = process.env.ADMIN_NOTIFY_EMAIL || 'owner@suponos.com'
  await transport.sendMail({
    to: adminEmail,
    from: process.env.FROM_EMAIL || 'no-reply@suponos.com',
    subject: `New reservation request: ${name} (${partySize})`,
    text: `When: ${startsAt.toISOString()}
Name: ${name}
Email: ${email}
Phone: ${phone}
Note: ${note}`
  })

  return NextResponse.json({ ok: true, id: row.id })
}
