import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function POST(_: Request, { params }: { params: { id: string } }){
  const id = parseInt(params.id,10)
  await prisma.reservation.update({ where: { id }, data: { status: 'DECLINED' } })
  return NextResponse.json({ ok: true })
}
