import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getTransport } from '@/lib/email'

export async function POST(_: NextRequest, { params }: { params: { id: string } }){
  const id = parseInt(params.id,10)
  const row = await prisma.reservation.update({ where: { id }, data: { status: 'APPROVED' } })
  const t = getTransport()
  await t.sendMail({
    to: row.email,
    from: process.env.FROM_EMAIL || 'no-reply@suponos.com',
    subject: 'Your reservation is confirmed',
    text: `See you at Supono's! Your reservation is confirmed for ${new Date(row.startsAt).toLocaleString()}.`
  })
  return NextResponse.json({ ok: true })
}
