import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'

export async function GET(){
  const s = await prisma.setting.findFirst()
  return NextResponse.json(s)
}

export async function PUT(req: Request){
  const body = await req.json()
  const s0 = await prisma.setting.findFirst()
  const s = await prisma.setting.upsert({
    where: { id: s0?.id || 1 },
    update: body,
    create: { ...(body || {}) }
  })
  return NextResponse.json(s)
}
