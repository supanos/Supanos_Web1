import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'

export async function GET(){
  const cats = await prisma.category.findMany({ orderBy: { order: 'asc' } })
  return NextResponse.json(cats)
}

export async function POST(req: Request){
  const body = await req.json()
  const name = String(body.name||'').trim()
  if (!name) return NextResponse.json({error:'name required'},{status:400})
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g,'-')
  const count = await prisma.category.count()
  const cat = await prisma.category.create({ data: { name, slug, order: count } })
  return NextResponse.json(cat)
}
