import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'

export async function POST(req: Request){
  const form = await req.formData()
  const title = String(form.get('title')||'')
  const description = String(form.get('description')||'')
  const price = Number(form.get('price')||0)
  const categoryId = Number(form.get('categoryId')||0)
  const tags = String(form.get('tags')||'').split(',').map(s=>s.trim()).filter(Boolean)
  const flags = String(form.get('flags')||'').split(',').map(s=>s.trim()).filter(Boolean)
  const contains = String(form.get('contains')||'').split(',').map(s=>s.trim()).filter(Boolean)

  if (!title || !price || !categoryId) return NextResponse.json({error:'missing fields'},{status:400})

  const item = await prisma.menuItem.create({ data: { title, description, price, categoryId, flags, contains } })

  if (tags.length) {
    for (const t of tags){
      const slug = t.toLowerCase().replace(/[^a-z0-9]+/g,'-')
      const tag = await prisma.tag.upsert({
        where: { slug },
        create: { name: t, slug },
        update: {}
      })
      await prisma.menuItemTag.create({ data: { itemId: item.id, tagId: tag.id } })
    }
  }
  return NextResponse.json({ ok: true, id: item.id })
}

export async function GET(){
  const items = await prisma.menuItem.findMany({ include: { category: true, tags: { include: { tag: true } } } })
  return NextResponse.json(items)
}
