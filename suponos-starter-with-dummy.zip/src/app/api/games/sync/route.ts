import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'

// Placeholder sync: seeds a few games. Later can connect to real APIs.
export async function POST(){
  const base = new Date(); base.setHours(20,0,0,0)
  const sample = [
    { league: 'MLB', awayTeam: 'Seattle Mariners', homeTeam: 'Cleveland Guardians', startsAt: new Date(base) },
    { league: 'MLB', awayTeam: 'Toronto Blue Jays', homeTeam: 'Milwaukee Brewers', startsAt: new Date(base.getTime()+20*60*1000) },
    { league: 'NFL', awayTeam: 'Ravens', homeTeam: 'Steelers', startsAt: new Date(base.getTime()+40*60*1000) },
  ] as any[]
  for (const g of sample){
    await prisma.game.create({ data: { ...g, status: 'SCHEDULED' } })
  }
  return NextResponse.json({ ok: true, added: sample.length })
}
