import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'

export async function GET(){
  const now = new Date()
  const start = new Date(now); start.setHours(0,0,0,0)
  const end = new Date(now); end.setHours(23,59,59,999)
  const rows = await prisma.game.findMany({ where: { startsAt: { gte: start, lte: end } }, orderBy: { startsAt: 'asc' } })
  return NextResponse.json(rows)
}
