import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'

export async function GET(){
  const rows = await prisma.game.findMany({ orderBy: { startsAt: 'asc' }, take: 200 })
  return NextResponse.json(rows)
}
