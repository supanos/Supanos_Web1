import './globals.css'
import Nav from '@/components/Nav'

export const metadata = {
  title: "Supono's Sports Bar",
  description: "Game day favorites, every match on big screens."
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Nav/>
        <main>{children}</main>
        <footer className="mt-12 border-t border-slate-800/70">
          <div className="container py-8 text-sm opacity-80">
            © {new Date().getFullYear()} Supono&apos;s — All rights reserved.
          </div>
        </footer>
      </body>
    </html>
  )
}
