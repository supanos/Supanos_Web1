// (Optional) You can add middleware for admin route protection later if needed.
export default function middleware() {}
