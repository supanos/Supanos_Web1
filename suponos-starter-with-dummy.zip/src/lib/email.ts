import nodemailer from 'nodemailer'

export function getTransport() {
  const host = process.env.SMTP_HOST
  const port = parseInt(process.env.SMTP_PORT || '587', 10)
  const secure = (process.env.SMTP_SECURE || 'false') === 'true'
  const user = process.env.SMTP_USER
  const pass = process.env.SMTP_PASS
  if (!host || !user || !pass) {
    // fallback transport that logs to console
    return {
      sendMail: async (opts: any) => {
        console.log('EMAIL (mock):', opts)
        return { messageId: 'mock' }
      }
    } as any
  }
  return nodemailer.createTransport({ host, port, secure, auth: { user, pass } })
}
