import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import { prisma } from './prisma'

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret'

export async function authenticate(username: string, password: string) {
  const user = await prisma.adminUser.findUnique({ where: { username } })
  if (!user) return null
  const ok = await bcrypt.compare(password, user.passwordHash)
  if (!ok) return null
  const token = jwt.sign({ sub: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '7d' })
  return token
}

export function verifyToken(token: string) {
  try { return jwt.verify(token, JWT_SECRET) as any }
  catch { return null }
}
