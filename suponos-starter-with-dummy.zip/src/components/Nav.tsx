'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

export default function Nav(){
  const p = usePathname()
  const links = [
    {href:'/',label:'Home'},
    {href:'/menu',label:'Menu'},
    {href:'/events',label:'Events'},
    {href:'/contact',label:'Contact'},
  ]
  return (
    <div className="border-b border-slate-800/70">
      <div className="container flex items-center justify-between py-3">
        <Link href="/" className="text-2xl font-black tracking-widest" style={{color:'var(--accent)'}}>
          SUPONO&apos;S
        </Link>
        <div className="flex gap-6">
          {links.map(l=>(
            <Link key={l.href} href={l.href} className={`hover:opacity-80 ${p===l.href?'text-[var(--accent)]':''}`}>{l.label}</Link>
          ))}
          <Link href="/reserve" className="btn">Reserve Table</Link>
        </div>
      </div>
    </div>
  )
}
