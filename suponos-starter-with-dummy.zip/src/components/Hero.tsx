export default function Hero(){
  return (
    <section className="relative">
      <div className="container py-24 text-center">
        <h1 className="text-5xl font-extrabold leading-tight">Tonight&apos;s Games<br/>at Supono&apos;s Sports Bar</h1>
        <p className="mt-4 opacity-80">Every touchdown, every home run — watch it here with the best crowd in town.</p>
        <div className="mt-6 flex gap-3 justify-center">
          <a className="btn" href="#today-matches">Tonight&apos;s Events</a>
          <a className="btn-outline" href="/promotions">Happy Hour</a>
        </div>
      </div>
    </section>
  )
}
